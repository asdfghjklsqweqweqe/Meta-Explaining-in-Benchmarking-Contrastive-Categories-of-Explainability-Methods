import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import pandas
from torch_geometric.datasets import TUDataset
import torch
from torch_geometric.loader import DataLoader
import Model_Loading as gcn_2l_model
from copy import deepcopy
import numpy as np
from time import perf_counter
import torch.nn.functional as F
from scipy.special import softmax
from statistics import mean


class LRP_GC(object):
    def __init__(self, task, method, graph, importance_threshold, load_index, input_dim, hid_dim, output_dim):

        self.GCN_model = self.load_model(task, method, load_index=load_index, input_dim=input_dim, hid_dim=hid_dim,
                                         output_dim=output_dim)
        self.criterion = torch.nn.CrossEntropyLoss()
        self.importance_dict = {}
        start_time = perf_counter()
        self.new_graph, self.saliency_maps = self.drop_important_nodes(self.GCN_model, graph, importance_threshold)
        self.it_took = perf_counter() - start_time

    def load_model(self, task, method, load_index, input_dim, hid_dim, output_dim):

        if load_index != 0:
            GCN_model, optimizer, load_index = self.loading_config(task, method, load_index, input_dim, hid_dim,
                                                                   output_dim)
            return GCN_model
        else:
            GCN_model = gcn_2l_model.GCN_2Layer_Model(model_level='graph', dim_node=input_dim, dim_hidden=hid_dim,
                                                      dim_output=output_dim)
            return GCN_model

    def loading_config(self, task, method, load_index, input_dim, hid_dim, output_dim):
        GCN_model = gcn_2l_model.GCN_2Layer_Model(model_level='graph', dim_node=input_dim, dim_hidden=hid_dim,
                                                  dim_output=output_dim)
        optimizer = torch.optim.Adam(params=GCN_model.parameters(), lr=0.001)
        checkpoint = torch.load(str(method) + " on " + str(task) + " classifier model_" + str(load_index)+".pt")
        GCN_model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        epoch = checkpoint['epoch']
        loss = checkpoint['loss']

        return GCN_model, optimizer, epoch

    def loss_calculations(self, preds, gtruth):
        loss_per_epoch = self.criterion(preds, gtruth)
        return loss_per_epoch

    def accumulate_weights(self, model_for_you):

        gconv1_weight = model_for_you.gconv1.weight.detach().tolist()

        gconv2_weight = model_for_you.gconv2.weight.detach().tolist()

        ffn_weight = model_for_you.ffn.weight.detach().tolist()

        return gconv1_weight, gconv2_weight, ffn_weight

    def GCN_Model_LRP(self, your_model, test_dataset):
        FFN_activations = []
        GConv2_activations = []
        GConv1_activations = []

        your_model.eval()
        for batch_of_graphs in test_dataset:
            post_conv1_test_activations, post_conv2_test_activations, lrp_gap, GCN_Model_test_activations = your_model(
                batch_of_graphs.x, batch_of_graphs.edge_index, batch_of_graphs.batch)
            GConv1_activations.append(post_conv1_test_activations.detach().tolist())
            GConv2_activations.append(post_conv2_test_activations.detach().tolist())
            FFN_activations.append(GCN_Model_test_activations.detach().tolist())

        return GConv1_activations, GConv2_activations, FFN_activations

    def my_relu(self, input):
        return np.maximum(0, input)

    def Compute_R_J(self, epsilon, preceding_layer_activations, exceding_layer_weights, next_layer_R_k, is_it_last):
        Denominators = []
        for i in range(len(preceding_layer_activations)):
            SUM_Denominator = 0
            for j in range(len(preceding_layer_activations[i])):
                for k in range(len(exceding_layer_weights[j])):
                    SUM_Denominator = SUM_Denominator + preceding_layer_activations[i][j] * self.my_relu(
                        exceding_layer_weights[j][k])
                Denominators.append(epsilon + SUM_Denominator)
        # print("Denominator is done: ", Denominators)
        # print("Denominator Length: ", len(Denominators))

        if is_it_last:
            Numerators = []
            for i in range(len(preceding_layer_activations)):
                Node_Numerator = []
                for j in range(len(preceding_layer_activations[i])):
                    SUM_Nominator = 0
                    for k in range(len(exceding_layer_weights[j])):
                        SUM_Nominator = SUM_Nominator + preceding_layer_activations[i][j] * self.my_relu(
                            exceding_layer_weights[j][k]) * next_layer_R_k[k]
                    Node_Numerator.append(SUM_Nominator)
                Numerators.append(Node_Numerator)
        else:
            Numerators = []
            for i in range(len(preceding_layer_activations)):
                Node_Numerator = []
                for j in range(len(preceding_layer_activations[i])):
                    SUM_Nominator = 0
                    for k in range(len(exceding_layer_weights[j])):
                        SUM_Nominator = SUM_Nominator + preceding_layer_activations[i][j] * self.my_relu(
                            exceding_layer_weights[j][k]) * next_layer_R_k[i][k]
                    Node_Numerator.append(SUM_Nominator)
                Numerators.append(Node_Numerator)

        R_Js_Graph = []
        for i in range(len(Numerators)):
            R_Js_Graph.append([x / Denominators[i] for x in Node_Numerator])

        return R_Js_Graph

    def Compute_R_K(self, FFN_activations, wrt):
        # print(FFN_activations)
        FFN_activations = FFN_activations[0]
        if wrt == 2:  # .     Graph Label
            last_layer_R_k = [0] * len(FFN_activations)
            last_layer_R_k[FFN_activations.index(max(FFN_activations))] = FFN_activations[
                FFN_activations.index(max(FFN_activations))]
            # print(last_layer_R_k)
            return last_layer_R_k
        elif wrt == 0:  # .    Class 0
            last_layer_R_k = [0] * len(FFN_activations)
            last_layer_R_k[0] = FFN_activations[0]
            # print(last_layer_R_k)
            return last_layer_R_k
        elif wrt == 1:  # .    Class 1
            last_layer_R_k = [0] * len(FFN_activations)
            last_layer_R_k[1] = FFN_activations[1]
            # print(last_layer_R_k)
            return last_layer_R_k

    def One_Graph_LRP(self, epsilon, wrt, graph_sample, weights, activations):
        GConv1_weight = weights[0]
        GConv1_weight_T = weights[1]

        GConv2_weight = weights[2]
        GConv2_weight_T = weights[3]

        FFN_weight = weights[4]
        FFN_weight_T = weights[5]

        GConv1_activations = activations[0]
        GConv2_activations = activations[1]
        FFN_activations = activations[2]

        last_layer_R_k = self.Compute_R_K(FFN_activations, wrt)
        # print("R_K: ",last_layer_R_k)
        R_J_hidden2 = self.Compute_R_J(epsilon, GConv2_activations, FFN_weight_T, last_layer_R_k, True)
        # print(R_J_hidden2)
        # print(len(R_J_hidden2))
        R_J_hidden1 = self.Compute_R_J(epsilon, GConv1_activations, GConv2_weight, R_J_hidden2, False)
        # print(R_J_hidden1)
        # print(len(R_J_hidden1))
        R_J_input = self.Compute_R_J(epsilon, graph_sample, GConv1_weight, R_J_hidden1, False)
        # print(R_J_input)
        # print(len(R_J_input))

        return R_J_input

    def Normalize_LRPs(self, your_model, dataset):
        GConv1_activations, GConv2_activations, FFN_activations = self.GCN_Model_LRP(your_model, dataset)
        GConv1_weight, GConv2_weight, FFN_weight = self.accumulate_weights(your_model)

        GConv1_weight_T = np.array(GConv1_weight).transpose()
        GConv1_weight_T = GConv1_weight_T.tolist()

        GConv2_weight_T = np.array(GConv2_weight).transpose()
        GConv2_weight_T = GConv2_weight_T.tolist()

        FFN_weight_T = np.array(FFN_weight).transpose()
        FFN_weight_T = FFN_weight_T.tolist()

        epsilon = 1e-16
        LRPs_Testset = []
        for i in range(len(dataset)):
            post_conv1_test_activations, post_conv2_test_activations, lrp_gap, GCN_Model_test_activations = your_model(
                dataset[i].x, dataset[i].edge_index, dataset[i].batch)
            wrt = GCN_Model_test_activations.argmax(dim=1).detach().tolist()[0]
            # print(wrt)
            LRPs_Testset.append(self.One_Graph_LRP(epsilon, wrt, dataset[i].x.detach().tolist(),
                                                   [GConv1_weight, GConv1_weight_T, GConv2_weight, GConv2_weight_T,
                                                    FFN_weight, FFN_weight_T],
                                                   [GConv1_activations[i], GConv2_activations[i], FFN_activations[i]]))
        Normalized_LRPs = []
        for i in range(len(LRPs_Testset)):
            Each_Graph = []
            for j in range(len(LRPs_Testset[i])):
                Each_Graph.append(sum(LRPs_Testset[i][j]))
            print(Each_Graph)
            norm = [(float(i)) / (max(Each_Graph) + 1e-16) for i in Each_Graph]
            Normalized_LRPs.append(norm)
        return Normalized_LRPs

    def is_salient(self, score, importance_threshold):

        # print(start, score, end)
        if importance_threshold <= score:
            return True
        else:
            return False

    def standardize_by_softmax(self, saliencies):
        softmaxed_attributions = []
        for graph_saliency in saliencies:
            #print(graph_saliency)
            #print("this is the softmax: ",softmax(graph_saliency))
            softmaxed_attributions.append(softmax(graph_saliency).tolist())
        standard_attributions = []
        for soft_atts in softmaxed_attributions:
            standard_graph = []
            for node_imp in soft_atts:
                #if (node_imp - mean(soft_atts)) != 0:
                standard_graph.append((node_imp) / (max(soft_atts)))
                #else:
                #    standard_graph.append(0)
            standard_attributions.append(standard_graph)

        return standard_attributions

    def drop_important_nodes(self, your_model, your_dataset, importance_threshold):
        LRP_attribution_scores = self.Normalize_LRPs(your_model, your_dataset)
        occluded_GNNgraph_list = []

        for i in range(len(LRP_attribution_scores)):
            sample_graph = deepcopy(your_dataset[i])
            graph_dict = {}
            for j in range(len(sample_graph.x)):

                if self.is_salient((LRP_attribution_scores[i][j]), importance_threshold):
                    # print("before: ", sample_graph.x[j])
                    sample_graph.x[j][:] = 0
                    # print(torch.zeros_like(sample_graph.x[j]))
                    # print("manipulated: ",sample_graph.x[j])
                    graph_dict[j] = True
                else:
                    graph_dict[j] = False
            self.importance_dict[i] = graph_dict
            occluded_GNNgraph_list.append(sample_graph)
        Standard_LRP_attribution_scores = self.standardize_by_softmax(LRP_attribution_scores)
        return occluded_GNNgraph_list, Standard_LRP_attribution_scores



#dataset = TUDataset(root='data/TUDataset', name='MUTAG')



#new_output = LRP_GC(task="Graph Classification", method="LRP", graph=[dataset[50]], importance_threshold=0.5, load_index=200, input_dim = len(dataset[0].x[0]), hid_dim = 7, output_dim = 2)
#print(new_output.new_graph[-1].x, dataset[-1].x)
#print(new_output.saliency_maps)
#print(new_output.importance_dict)